# carsim_fullcar 후반부525조건 인계 번들

이 ZIP은 **원래 조건 ID526~1050**의 안정영역을 다른 대화·실행 환경에서 계산하기 위한 최소 프로젝트입니다. 기존 대화는 **ID1~525**를 담당합니다. ID 범위를 바꾸거나 두 대화가 같은 작업 폴더를 공유하지 마세요.

전체 작업 지시는 [HANDOFF_PROMPT.md](stable_region/handoff/HANDOFF_PROMPT.md)에 있습니다. 다른 대화에는 그 파일 내용과 이 ZIP을 함께 전달하세요. GitHub 업로드와 두 절반의 최종 병합 절차도 들어 있습니다.

## 포함 내용

- 기존 `result/` 1,050회 실행에 사용한 원래34상태 모델·물리 데이터·보정·C++ 원본.
- 검증된 원래 두 GNU Octave MEX와 대응 런타임 설치 잠금·설정 도구.
- 조건526~1050의 준비된525개 컨텍스트, 원래1,050조건 인덱스와 설정·서명.
- 범위별 배치 실행, 수치 감사, 조건별 이미지 생성, 범위 소유 파일만 GitHub 브랜치에 올리는 코드.
- 파일 SHA-256 목록과 검사 도구, 상세 인계 프롬프트.

원래 약3.5GB의 `result/` 주행 궤적, Git 인증정보, MathWorks 계정·라이선스는 포함하지 않습니다. 컨텍스트는 계산 입력이며 이미 완성된 안정영역525개가 아닙니다.

## 순서

1. ZIP을 별도 임시 디렉터리에 풉니다. 최상위 폴더는 `suspension_pro_handoff_526_1050/`입니다.
2. 그 프로젝트 루트에서 `python stable_region/handoff/verify_handoff.py`로 파일 해시를 확인합니다.
3. 상세 프롬프트의 sparse clone 예제에 따라 별도 Git 작업 폴더와 `stable-region-526-1050` 브랜치를 준비합니다. 이미 실행 중인 기존 대화의 checkout이나 프로세스를 건드리지 않습니다.
4. 해시가 확인된 프로젝트 파일·후반부 컨텍스트·MEX를 그 작업 폴더에 배치합니다. 다른 바이트의 원본 소스를 덮어쓰며 오류를 없애지 않습니다.
5. `bash stable_region/handoff/runtime/setup_octave.sh`로 잠긴 Octave10.3 환경을 설치하고 런타임 smoke 검사를 통과시킵니다. 새 환경에서는 의존 패키지 다운로드와 수GB의 여유 공간이 필요합니다.
6. 아래 범위 명령으로 실제 계산·이미지 생성·브랜치 업로드를 시작합니다.

```sh
chmod +x stable_region/handoff/runtime/run_octave.sh
python -m pip install -r stable_region/code/requirements.txt
python stable_region/code/run_region_batch.py \
  --runtime-wrapper stable_region/handoff/runtime/run_octave.sh \
  --octave octave-cli --skip-prepare \
  --start-id 526 --end-id 1050 \
  --shard-name second_0526_1050 \
  --publish-branch stable-region-526-1050 \
  --publish-every 25
```

명령을 실행하기 전 실제 `--help`와 상세 인계 프롬프트를 확인하세요. 이 작업은 이미지를 포함하므로 `--no-images`를 쓰지 않습니다. 모델·판정 기준·격자 해상도를 바꾸지 않습니다.

진행률·잠금·범위별 서명은 `stable_region/carsim_fullcar_1050/shards/second_0526_1050/`에 저장됩니다. 결과는 원래 ID를 유지한 `regions/case_0526.mat`~`case_1050.mat`와 대응 `images/`에 저장합니다. 이 범위가 끝나면 `525/525` 또는 `range_complete`로 보고합니다. 전체1,050개 완료와 구분하세요.

GitHub에는 이 범위의 MAT·PNG·이미지 JSON과 자기 shard의 상태만 올립니다. 원격 push 후 브랜치 SHA를 확인하세요. 최종 병합은 `https://github.com/yodagil/suspension_pro/compare/main...stable-region-526-1050`에서 준비할 수 있습니다.

전체 ID1~1050의 누락·중복·수치·이미지·입력/엔진 서명을 검증한 뒤에만 `--finalize-global`로 통합 LUT·QC CSV를 완성합니다. 후반부만 계산한 상태에서 누락된 전반부를0으로 채우면 안 됩니다.
